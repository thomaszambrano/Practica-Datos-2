import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class Bubble {

    public static void bubbleSort(List<String> arr) {
        int n = arr.size();
        for (int i = 0; i < n-1; i++) {
            for (int j = 0; j < n-i-1; j++) {
                if (arr.get(j).compareTo(arr.get(j+1)) > 0) {
                    // Intercambiar elementos
                    Collections.swap(arr, j, j+1);
                }
            }
        }
    }

    public static void main(String[] args) {
        List<String> data = loadData("palabras.txt", 247047);  // Cargar datos
        long startTime = System.nanoTime();

        bubbleSort(data);  // Ejecutar Bubble Sort

        long endTime = System.nanoTime();
        double duration = (endTime - startTime) / 1e9;
        System.out.println("Tiempo de ejecución Bubble Sort: " + duration + " segundos");
    }

    // Método para cargar datos desde un archivo
    public static List<String> loadData(String filePath, int numWords) {
        List<String> data = new ArrayList<>();
        try (java.util.Scanner scanner = new java.util.Scanner(new java.io.File("palabras.txt"))) {
            int count = 0;
            while (scanner.hasNext() && count < numWords) {
                data.add(scanner.next());
                count++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }
}
