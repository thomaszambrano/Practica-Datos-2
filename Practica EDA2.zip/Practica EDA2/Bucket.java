import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class Bucket {

    public static void bucketSort(List<String> arr) {
        int n = arr.size();
        List<List<String>> buckets = new ArrayList<>(n);

        // Crear las cubetas (buckets)
        for (int i = 0; i < n; i++) {
            buckets.add(new ArrayList<>());
        }

        // Distribuir elementos en cubetas según el tamaño de la palabra
        for (String word : arr) {
            int index = word.length() % n;
            buckets.get(index).add(word);
        }

        // Ordenar individualmente cada cubeta
        for (List<String> bucket : buckets) {
            Collections.sort(bucket);
        }

        // Concatenar las cubetas ordenadas
        int idx = 0;
        for (List<String> bucket : buckets) {
            for (String word : bucket) {
                arr.set(idx++, word);
            }
        }
    }

    public static void main(String[] args) {
        List<String> data = loadData("palabras.txt", 247047);  // Cargar datos
        long startTime = System.nanoTime();

        bucketSort(data);  // Ejecutar Bucket Sort

        long endTime = System.nanoTime();
        double duration = (endTime - startTime) / 1e9;
        System.out.println("Tiempo de ejecución Bucket Sort: " + duration + " segundos");
    }

    // Método para cargar datos desde un archivo
    public static List<String> loadData(String filePath, int numWords) {
        List<String> data = new ArrayList<>();
        try (java.util.Scanner scanner = new java.util.Scanner(new java.io.File("palabras.txt"))) {
            int count = 0;
            while (scanner.hasNext() && count < numWords) {
                data.add(scanner.next());
                count++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }
}
